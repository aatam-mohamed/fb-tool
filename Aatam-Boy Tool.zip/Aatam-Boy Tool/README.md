# Facebook
Hacking Tools And Facebook Bot

## LOGIN:
- [x] NORMAL LOGIN (api)
- [x] NORMAL LOGIN (mbasic)
- [x] ACCESS TOKEN LOGIN
- [x] Cookie Login

## FEATURES:
- [x] User Information
- [x] Mini Hack Facebook (Target)
- [x] Multi Bruteforce Facebook
- [x] Super Multi Bruteforce Facebook
- [x] BruteForce (Target)
- [x] Get ID From Friends
- [x] Get Friends ID From Friends
- [x] Get Friends Email
- [x] Get Friends Email From Friends
- [x] Get Phone From Friends
- [x] Get Friend  Phone From Friends
- [x] BOT Target Post Reaction
- [x] BOT Group Post Reactions
- [x] BOT Comments Reactions
- [x] BOT Random Target Post Reaction
- [x] BOT Random Group Post Reaction
- [x] BOT Comment Target Post
- [x] BOT Comment Group Post
- [x] BOT Reply Comment
- [x] BOT Spam Comment
- [x] BOT Add Friend From Target Id
- [x] BOT Add Friend From Friend
- [x] BOT Add Friend From File Id
- [x] BOT Follow target Id
- [x] BOT Follow all friend
- [x] BOT Follow Friend from Friend
- [x] BOT Follow From File Id
- [x] BOT Share Post To Facebook
- [x] BOT Share Post on a Friend's Timeline
- [x] BOT Share Post on a Page
- [x] BOT Delete Post
- [x] BOT Unfriends
- [x] BOT Unfollow
- [x] Write Status
- [x] Write Timeline
- [x] Create Wordlist
- [x] Account Checker
- [x] See my group list
- [x] Get User Access Token
- [x] Frofil Picture Guard
- [x] Download Video
- [x] Publication of Posts on Pages
- [x] Publish Links On Pages
- [x] Comment Post Page Bot
- [x] Comment Spam Page Bot
- [x] Page Bot Delete Post
- [x] Get Page Access Token

## INSTALLATION
	$ pkg upgrade && pkg update

	$ pkg install ruby
	
	$ pkg install git
	
	$ git clone https://github.com/MR-X-Junior/Facebook
	
	$ cd Facebook
	
	$ ruby main.rb
